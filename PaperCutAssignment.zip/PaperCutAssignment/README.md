PaperCut Portal Assignment
====================

TODO - Put instructions here what are included in this folder and how to run it
