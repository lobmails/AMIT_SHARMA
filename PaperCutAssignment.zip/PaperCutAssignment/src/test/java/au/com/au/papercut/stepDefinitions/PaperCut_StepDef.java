package au.com.au.papercut.stepDefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import au.com.au.papercut.serenity.PaperCut_Steps;


/**
 * Created by amitks on 2/14/2017.
 */
public class PaperCut_StepDef {

    @Steps
    PaperCut_Steps paperCut;

    @Given("^the PaperCut portal is launched$")
    public void the_PaperCut_portal_is_launched() throws Throwable {
        paperCut.launchApp();   
    }
    
    @When("^clicks on \"([^\"]*)\"$")
    public void clicks_on(String arg1) throws Throwable {
        paperCut.clickButton(arg1);
    }
   
    @And("^click on \"([^\"]*)\" Button$")
    public void click_on(String arg1) throws Throwable {
        paperCut.clickButton(arg1);
    }
    
    @And("^I signin with my Google (.*) and (.*)$")
    public void iSigninWithMyGoogleEmailAndPassword(String Email, String Password) throws Throwable {
        paperCut.loginApp(Email, Password);
    }
    
    @And("^I skip the guided tour of the application$")
    public void I_skip_the_guided_tour_of_the_application() throws Throwable {
        paperCut.skipTour();
    }
    
    @Then("^verify profile page displayed \"([^\"]*)\" with the (.*)$")
    public void verifyProfilePageDisplayedWithTheEmail(String email, String emailValue) throws Throwable {
    	paperCut.verifyObjOnPage(email, emailValue);
    }
    
    @Then("^verify \"([^\"]*)\" printer is \"([^\"]*)\" status$")
    public void verifyPrinterIsStatus(String printerName, String printerStatus) throws Throwable {
    	paperCut.verifyPrinterState(printerName, printerStatus);
        // 
    }
    
    @Then("^verify the total number of pages printed this month$")
    public void verifyTheTotalNumberOfPagesPrintedThisMonth() throws Throwable {
        paperCut.verifyPageCount();
    }
    
    @Then("^verify the forecast for each ink block for \"([^\"]*)\" for (\\d+) days$")
    public void verifyTheForecastForEachInkBlockForForDays(String printerName, int days) throws Throwable {
    	paperCut.verifyTotalPrintsForEachInkBlock(printerName, days);
    }
}