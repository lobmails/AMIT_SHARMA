package au.com.au.papercut.pageObjects;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.junit.Assert;

import java.util.concurrent.TimeUnit;

/**
 * Created by amitks on 2/14/2017.
 */
public class LoginPage extends PageObject{

    public void goToThisURL(String namedURL){
        getDriver().navigate().to(namedURL);
    }

    @FindBy(xpath = "//input[@id='Email' and @name='Email']")
    WebElementFacade usernameField;

    @FindBy(xpath = "//input[@id='Passwd' and @name='Passwd']")
    WebElementFacade passwordField;

    @FindBy(xpath="//input[@id='next' and @type='submit']")
    WebElementFacade btnNext;
    
    @FindBy(xpath = "//input[@id='signIn']")
    WebElementFacade loginButton;

    public LoginPage(WebDriver driver){
        super(driver);
    }
    public void login(String userName, String passWord) throws InterruptedException {
        if(!getDriver().findElements(By.xpath("//span[text()='"+userName+"']")).isEmpty()){
        	if(getDriver().findElement(By.xpath("//span[text()='"+userName+"']")).getText().equals(userName)){
        		getDriver().findElement(By.xpath("//a[@class='ui button google social']")).click();
        	}
        }else if(!getDriver().findElements(By.xpath("//a[text()='Add account']")).isEmpty()){
        	getDriver().findElements(By.xpath("//a[text()='Add account']")).get(0).click();
        }
        
        usernameField.type(userName);
        btnNext.click();
        Thread.sleep(2000);
        passwordField.type(passWord);
        loginButton.click();
        int i = 0;
        while(!getDriver().getCurrentUrl().contains("dashboard")){
        	Thread.sleep(1000);
        	if(i>=60){ break; }
        	i+=1;
        }
        waitForWithRefresh();
        Assert.assertEquals("User has logged in successfuly and is on dasboard page", true, getDriver().getCurrentUrl().contains("dashboard"));
    }
}
