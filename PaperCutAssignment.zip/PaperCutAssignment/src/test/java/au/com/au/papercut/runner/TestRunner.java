package au.com.au.papercut.runner;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

/**
 * Created by amitks on 2/14/2017.
 */

@RunWith(CucumberWithSerenity.class)

@CucumberOptions(
        features = {
                "./src/test/resources/features/PaperCutPortal"
        },
        tags = "@Reg",
        plugin = {"pretty", "html:target/cucumber"},
        glue = {"au.com.au.papercut.stepDefinitions",
               "au.com.au.papercut.hooks"}
)
public class TestRunner {
}
