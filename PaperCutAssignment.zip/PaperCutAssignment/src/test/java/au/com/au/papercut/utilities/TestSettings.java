package au.com.au.papercut.utilities;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;

/**
 * Created by amitks on 2/14/2017.
 */
public class TestSettings {
    public static TestSettings instance;
    public static HashMap<String, String> _inputMap;
    public static Properties constantsProp = new Properties();
    public static Properties locatorsProp = new Properties();
    public static Properties testSettingsProp = new Properties();

    public static TestSettings getInstance(){
        if (instance == null){
            instance = new TestSettings();
        }
        return instance;
    }

    public void loadConstantsProperties() {
        try {
            InputStream in = null;
            System.out.println("****Selected Environment = " +System.getProperty("ENV"));
                in = this.getClass().getClassLoader().getResourceAsStream("properties/Test.properties");

            if (in != null) {
                constantsProp.load(in);
            }
            System.out.println(constantsProp.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public TestSettings() {
        loadConstantsProperties();
        System.out.println("LOADED CONSTANTS PROPERTIES");
    }

    public Properties getConstantsProp() {
        return constantsProp;
    }

    public static void main(String[] args) throws IOException {
        TestSettings ts = TestSettings.getInstance();
    }
}
