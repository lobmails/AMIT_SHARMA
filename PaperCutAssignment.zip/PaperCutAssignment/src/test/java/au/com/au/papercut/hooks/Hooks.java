package au.com.au.papercut.hooks;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import net.serenitybdd.core.annotations.findby.By;
import net.thucydides.core.annotations.Managed;

import org.openqa.selenium.WebDriver;

import au.com.au.papercut.utilities.TestSettings;

import java.util.Properties;

/**
 * Created by amitks on 02/14/2017.
 */
public class Hooks {

    @Managed(uniqueSession = true, driver = "chrome")
    WebDriver driver;
    public static TestSettings testSettings;
    public static Properties constants;

    public Hooks(){
        System.out.println("--------------------INITIALIZE HOOKS----------------------");
        testSettings = TestSettings.getInstance();
        constants = testSettings.getConstantsProp();
    }

    @Before
    public void BeforeScenario(){
        System.out.println("--------------------BEFORE SCENARIO----------------------");
        driver.manage().window().maximize(); 
    }

    @After
    public void AfterScenario(){
        System.out.println("--------------------AFTER SCENARIO----------------------");
        driver.findElement(By.xpath("//li/a/div/strong")).click();
        driver.findElement(By.xpath("//a[text()='Sign Out']")).click();
        driver.quit();
    }

}