package au.com.au.papercut.pageObjects;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import java.io.IOException;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by amitks on 2/14/2017.
 */

public class HomePage extends PageObject {

	 @FindBy(xpath = "//a[text()='Get Started Now']")
	 WebElementFacade btnGetStartedNow;

	 @FindBy(xpath = "//a[@class='ui button google social']")
	 WebElementFacade btnContinueWithGoogle;
    
	 @FindBy(xpath = "//h5[text()='Label Printer (desktop)']")
	 WebElementFacade lblPrinterDesktop;
	 
	 @FindBy(xpath = "//h5[text()='A3 Printer (server)']")
	 WebElementFacade lblA3Printer;
	 
	 @FindBy(xpath = "//h5[text()='Accounts Printer (laptop)']")
	 WebElementFacade lblAccountsPrinter;
	 
	 @FindBy(xpath = "//div/h4[text()='Toner/Ink']/following-sibling::div[@class='button-group']/button[text()='See Forecast']")
	 WebElementFacade btnSeeForecastInkToner;
	 
	 @FindBy(xpath = "//header[contains(text(), 'Ink/Toner Forecast')]/i/span")
	 WebElementFacade btnCloseInkToner;
	 
    public void goToThisURL(String namedURL) throws InterruptedException{
        getDriver().navigate().to(namedURL); 
        Thread.sleep(2000);
        btnGetStartedNow.waitUntilClickable();
        Assert.assertEquals("Application is on home page", btnGetStartedNow.isCurrentlyVisible(), true);
    }
    
    public void skipDemoTour(){
    	if(!getDriver().findElements(By.xpath("//a[@class='skip' and text()='Skip Tour']")).isEmpty()){
    		getDriver().findElement(By.xpath("//a[@class='skip' and text()='Skip Tour']")).click();
    	}
    }
    
    public void verifyObjectOnPage(String verifyObj, String verifyObjProperty) {
		if(verifyObj.equals("Email")) {
            Assert.assertEquals("Email id is visible", true, getDriver().findElement(By.xpath("//span[text()='"+verifyObjProperty+"']")).isDisplayed());
        }else if(verifyObj.equals("--")) {
            Assert.assertEquals("-- is visible", true, true);
        }
	}

    public HomePage(WebDriver driver){
        super(driver);
    }
    
    /*This method is to click the required Button*/
    public void clickRequiredButton(String btnName) throws InterruptedException, IOException {
        if(btnName.equals("Get Started Now")) {
            btnGetStartedNow.click();
        }else if(btnName.equals("Continue with Google")) {
        	btnContinueWithGoogle.click();
        }
    }

	public void verifyPrinterStatus(String printerName, String printerStatus) {
		if(printerName.equals("Label Printer (desktop)") | printerName.equals("A3 Printer (server)")) {
			Assert.assertEquals(printerName + " - Printer is displayed in "+ printerStatus + " state", true, getDriver().findElement(By.xpath("//h4[text()='"+printerStatus+"']/../ul/li/a/span/div/h5[text()='"+printerName+"']")).isDisplayed());
        }else if(printerName.equals("Reception Printer (server)")) {
			Assert.assertEquals(printerName + " - Printer is displayed in "+ printerStatus + " state", true, getDriver().findElement(By.xpath("//h4/a[text()='"+printerStatus+"']/../../ul/li/a/span/div/h5[text()='"+printerName+"']")).isDisplayed());
        }	//
	}

	public void getPageCountForCurrentMonth() {
		Assert.assertEquals("Total Print Count for current month " + getDriver().findElement(By.xpath("//span[@id='pagessummary-monthlytotal']/*/span")).getText(), true, true);		
	}

	public void verifyInkBlockCountForPrinter(String printerName, int days) throws InterruptedException {
		btnSeeForecastInkToner.click();
		Thread.sleep(2000);
		if(days>30){
			getDriver().findElement(By.xpath("//li[text()='"+days+" days']")).click();
			Thread.sleep(1000);
		}
		//Using assert deliberately to enhance with expected value comparison
		Assert.assertEquals("Printer '"+printerName+"' Ink/Toner Forecast for Cyan toner: " + getDriver().findElement(By.xpath("//td[text()='"+printerName+"']/following-sibling::td[contains(@class, 'cyan')]/span")).getText()+"'", true, true);
		Assert.assertEquals("Printer '"+printerName+"' Ink/Toner Forecast for Magenta toner: " + getDriver().findElement(By.xpath("//td[text()='"+printerName+"']/following-sibling::td[contains(@class, 'magenta')]/span")).getText()+"'", true, true);
		Assert.assertEquals("Printer '"+printerName+"' Ink/Toner Forecast for Yellow toner: " + getDriver().findElement(By.xpath("//td[text()='"+printerName+"']/following-sibling::td[contains(@class, 'yellow')]/span")).getText()+"'", true, true);
		Assert.assertEquals("Printer '"+printerName+"' Ink/Toner Forecast for Black toner: " + getDriver().findElement(By.xpath("//td[text()='"+printerName+"']/following-sibling::td[contains(@class, 'black')]/span")).getText()+"'", true, true);		
		btnCloseInkToner.click();	
		
	}
}
