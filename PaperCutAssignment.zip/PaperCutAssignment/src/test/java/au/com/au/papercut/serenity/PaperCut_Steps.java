package au.com.au.papercut.serenity;

import au.com.au.papercut.pageObjects.*;
import net.thucydides.core.annotations.Step;
import java.io.IOException;
import java.util.Properties;
import au.com.au.papercut.utilities.TestSettings;

/**
 * Created by amitks on 2/14/2017.
 */
public class PaperCut_Steps {

    HomePage homePage;
    LoginPage loginPage;

    @Step
    public void launchApp() throws Throwable{
        TestSettings ts = TestSettings.getInstance();
        Properties constants = ts.getConstantsProp();
        String thisURL = constants.getProperty("PaperCutPortal");
        homePage.goToThisURL(thisURL);
    }
    
    @Step
    public void loginApp(String Email, String Password){
        //loginPage.login("papercut.assignment@gmail.com", "PaperCut123#");
    	try {
			loginPage.login(Email, Password);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
    
    @Step
    public void skipTour(){
    	homePage.skipDemoTour();
    }
    
    @Step
	public void verifyObjOnPage(String verifyObj, String verifyObjProperty) {
		homePage.verifyObjectOnPage(verifyObj, verifyObjProperty);		
	}

    @Step
    public void clickButton(String button) throws InterruptedException, IOException {
        homePage.clickRequiredButton(button);
    }

    @Step
	public void verifyPrinterState(String printerName, String printerStatus) {
		homePage.verifyPrinterStatus(printerName, printerStatus);
	}

    @Step
	public void verifyPageCount() {
    	homePage.getPageCountForCurrentMonth();
	}

    @Step
	public void verifyTotalPrintsForEachInkBlock(String printerName, int days) throws InterruptedException {
		homePage.verifyInkBlockCountForPrinter(printerName, days);
	}

}
